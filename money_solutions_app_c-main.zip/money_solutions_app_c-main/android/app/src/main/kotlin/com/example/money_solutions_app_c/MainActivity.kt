package com.example.money_solutions_app_c

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
