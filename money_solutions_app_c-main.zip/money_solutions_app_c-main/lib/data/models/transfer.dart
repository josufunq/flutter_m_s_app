import 'package:hive/hive.dart';

part 'transfer.g.dart';

@HiveType(typeId: 1)
class Transfer extends HiveObject {
  @HiveField(0)
  final String uid;
  @HiveField(1)
  final String name;
  @HiveField(2)
  final double count;
  @HiveField(3)
  final DateTime date;
  @HiveField(4)
  final String image;
  @HiveField(5)
  final int type;
  @HiveField(6)
  final String typeName;
  @HiveField(7)
  final String description;

  Transfer({
    required this.uid,
    required this.name,
    required this.count,
    required this.date,
    required this.image,
    required this.type,
    required this.typeName,
    required this.description,
  });
}
