import 'package:hive/hive.dart';
import 'package:money_solutions_app_c/data/models/credit_card.dart';

part 'account.g.dart';

@HiveType(typeId: 2)
class Account extends HiveObject {
  @HiveField(0)
  final String name;
  @HiveField(1)
  final List<CreditCard> cards;

  Account({
    required this.name,
    required this.cards,
  });
}
