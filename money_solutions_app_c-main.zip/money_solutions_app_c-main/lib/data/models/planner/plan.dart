import 'package:hive/hive.dart';

part 'plan.g.dart';

@HiveType(typeId: 3)
class Plan extends HiveObject {
  @HiveField(0)
  final String title;
  @HiveField(1)
  final DateTime dateStart;
  @HiveField(2)
  final DateTime dateEnd;
  @HiveField(3)
  final double income;
  @HiveField(4)
  final double unexpectedIncome;
  @HiveField(5)
  final List<double> outcomes;
  @HiveField(6)
  final double additionalOutcome;

  Plan({
    required this.title,
    required this.dateStart,
    required this.dateEnd,
    required this.income,
    required this.unexpectedIncome,
    required this.outcomes,
    required this.additionalOutcome,
  });

  Plan copyWith({
    String? title,
    DateTime? dateStart,
    DateTime? dateEnd,
    double? income,
    double? unexpectedIncome,
    List<double>? outcomes,
    double? additionalOutcome,
  }) {
    return Plan(
      title: title ?? this.title,
      dateStart: dateStart ?? this.dateStart,
      dateEnd: dateEnd ?? this.dateEnd,
      income: income ?? this.income,
      unexpectedIncome: unexpectedIncome ?? this.unexpectedIncome,
      outcomes: outcomes ?? this.outcomes,
      additionalOutcome: additionalOutcome ?? this.additionalOutcome,
    );
  }
}
