class Subscription {
  final String subscriptionName;
  final String imageAsset;

  Subscription({required this.subscriptionName, required this.imageAsset});
}
