import 'package:hive/hive.dart';

part 'credit_card.g.dart';

@HiveType(typeId: 0)
class CreditCard extends HiveObject {
  @HiveField(0)
  final String uid;
  @HiveField(1)
  final double balance;
  @HiveField(2)
  final DateTime expirationDate;

  CreditCard({
    required this.uid,
    required this.balance,
    required this.expirationDate,
  });
}
