import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:money_solutions_app_c/app_router.dart';
import 'package:money_solutions_app_c/data/models/account/account.dart';
import 'package:money_solutions_app_c/data/models/credit_card.dart';
import 'package:money_solutions_app_c/data/models/planner/plan.dart';
import 'package:money_solutions_app_c/data/models/transfer.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/shapes.dart';
import 'package:path_provider/path_provider.dart' as path_provider;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final appDocumentDir = await path_provider.getApplicationDocumentsDirectory();
  Hive.init(appDocumentDir.path);
  Hive.registerAdapter(CreditCardAdapter());
  Hive.registerAdapter(TransferAdapter());
  Hive.registerAdapter(AccountAdapter());
  Hive.registerAdapter(PlanAdapter());

  runApp(MainApp());
}

class MainApp extends StatelessWidget {
  MainApp({super.key});

  final AppRouter _appRouter = AppRouter();

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      routerConfig: _appRouter.config(),
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Inter',
        brightness: Brightness.dark,
        colorScheme: const ColorScheme.dark(
          background: AppColors.backgroundColor,
          surface: AppColors.surfaceColor,
        ),
        cardTheme: const CardTheme(
          elevation: 0,
          shape: largeShape,
          clipBehavior: Clip.antiAlias,
          margin: EdgeInsets.zero,
          color: AppColors.surfaceColor,
        ),
      ),
    );
  }
}
