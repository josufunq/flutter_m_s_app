part of 'transaction_cubit.dart';

@freezed
class TransactionState with _$TransactionState {
  const factory TransactionState.initial() = _Initial;
  const factory TransactionState.loading() = _Loading;
  const factory TransactionState.loadSuccess(List<Transfer> transfers) = _LoadSuccess;
  const factory TransactionState.addSuccess() = _AddSuccess;
  const factory TransactionState.error(String error) = _Error;
}
