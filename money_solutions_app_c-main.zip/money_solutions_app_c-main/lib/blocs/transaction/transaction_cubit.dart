import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:hive/hive.dart';
import 'package:money_solutions_app_c/data/models/transfer.dart';

part 'transaction_state.dart';
part 'transaction_cubit.freezed.dart';

class TransactionCubit extends Cubit<TransactionState> {
  TransactionCubit() : super(const TransactionState.initial());

  Future<void> loadTransfers() async {
    try {
      emit(const TransactionState.loading());

      List<Transfer> transfers = [];

      var transferBox = await Hive.openBox<Transfer>('transfers');
      transfers.addAll(transferBox.values);
      print(transferBox.values.length);
      transfers.sort((a, b) => b.date.compareTo(a.date));
      transferBox.close();

      emit(TransactionState.loadSuccess(transfers));
    } catch (e) {
      emit(TransactionState.error(e.toString()));
    }
  }

  Future<void> addTransfer(Transfer transfer) async {
    try {
      emit(const TransactionState.loading());

      var transferBox = await Hive.openBox<Transfer>('transfers');
      transferBox.add(transfer);
      transferBox.close();

      emit(const TransactionState.addSuccess());
    } catch (e) {
      emit(TransactionState.error(e.toString()));
    }
  }
}
