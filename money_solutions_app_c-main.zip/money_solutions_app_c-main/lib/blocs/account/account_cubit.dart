import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:hive/hive.dart';
import 'package:money_solutions_app_c/data/models/account/account.dart';
import 'package:money_solutions_app_c/data/models/credit_card.dart';

part 'account_state.dart';
part 'account_cubit.freezed.dart';

class AccountCubit extends Cubit<AccountState> {
  AccountCubit() : super(const AccountState.initial());

  void loadAccountData() async {
    try {
      emit(const AccountState.loading());

      Account? userAccount;

      var accountBox = await Hive.openBox<Account>('account');
      print(accountBox.values.toList().length);
      userAccount = accountBox.get('account');
      print(userAccount);
      await accountBox.close();

      emit(AccountState.successLoaded(userAccount));
    } catch (e) {
      print(e);
      emit(AccountState.error(e.toString()));
    }
  }

  void saveAccountData(Account account) async {
    try {
      var accountBox = await Hive.openBox<Account>('account');
      await accountBox.put('account', account);
      await accountBox.close();

      emit(const AccountState.successSaved());
    } catch (e) {
      print(e);
      emit(AccountState.error(e.toString()));
    }
  }

  void changeBalance(double count, int cardId) async {
    try {
      Account? userAccount;

      var accountBox = await Hive.openBox<Account>('account');
      userAccount = accountBox.get('account');
      userAccount = Account(
        name: userAccount!.name,
        cards: [
          CreditCard(
            uid: userAccount.cards[0].uid,
            balance: userAccount.cards[0].balance + count,
            expirationDate: userAccount.cards[0].expirationDate,
          )
        ],
      );

      await accountBox.put('account', userAccount);
    } catch (e) {
      print(e);
      emit(AccountState.error(e.toString()));
    }
  }
}
