part of 'account_cubit.dart';

@freezed
class AccountState with _$AccountState {
  const factory AccountState.initial() = _Initial;
  const factory AccountState.loading() = _Loading;
  const factory AccountState.error(String error) = _Error;
  const factory AccountState.successLoaded(Account? account) = _SuccessLoaded;
  const factory AccountState.successSaved() = _SuccessSaved;
}
