part of 'plan_cubit.dart';

@freezed
class PlanState with _$PlanState {
  const factory PlanState.initial() = _Initial;
  const factory PlanState.loading() = _Loading;
  const factory PlanState.loadSuccess(List<Plan> plans) = _LoadSuccess;
  const factory PlanState.addSuccess() = _AddSuccess;
  const factory PlanState.error(String error) = _Error;
}
