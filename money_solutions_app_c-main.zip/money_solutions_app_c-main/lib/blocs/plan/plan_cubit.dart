import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:hive/hive.dart';
import 'package:money_solutions_app_c/data/models/planner/plan.dart';

part 'plan_state.dart';
part 'plan_cubit.freezed.dart';

class PlanCubit extends Cubit<PlanState> {
  PlanCubit() : super(const PlanState.initial());

  Future<void> addPlan(Plan plan) async {
    try {
      emit(const PlanState.loading());

      var planBox = await Hive.openBox<Plan>('plans');

      await planBox.add(plan);
      await planBox.close();

      emit(const PlanState.addSuccess());
    } catch (e) {
      print(e);
      emit(PlanState.error(e.toString()));
    }
  }

  Future<void> loadPlans() async {
    try {
      emit(const PlanState.loading());

      var planBox = await Hive.openBox<Plan>('plans');
      List<Plan> plans = planBox.values.toList();
      await planBox.close();

      emit(PlanState.loadSuccess(plans));
    } catch (e) {
      emit(PlanState.error(e.toString()));
    }
  }
}
