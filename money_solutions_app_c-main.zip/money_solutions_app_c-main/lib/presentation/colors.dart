import 'dart:ui';

import 'package:flutter/material.dart';

class AppColors {
  static const primaryColor = Color(0xFF54B541);
  static const surfaceColor = Color(0xFF212223);

  static const descriptionColor = Color(0xFF747683);
  static const backgroundColor = Color(0xFF08090A);
  static const grey900 = Color(0xFF1A202C);

  static const textColor = Colors.black;
  static const secondaryTextColor = Color(0xFF9C9D9D);
}
