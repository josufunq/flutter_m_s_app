import 'package:flutter/material.dart';

class ClassicTextField extends StatelessWidget {
  final String hint;
  final TextStyle hintStyle;
  final TextStyle style;
  final TextAlign textAlign;
  final TextEditingController controller;
  final bool readOnly;
  final Function(String)? onChanged;
  final Function()? onEditingComplete;

  const ClassicTextField({
    super.key,
    required this.hint,
    this.hintStyle = const TextStyle(
      fontSize: 15,
      fontWeight: FontWeight.w600,
      color: Color(0xFF747474),
    ),
    this.style = const TextStyle(
      fontSize: 15,
      fontWeight: FontWeight.w600,
      color: Colors.white,
    ),
    this.textAlign = TextAlign.center,
    required this.controller,
    this.readOnly = false,
    this.onChanged,
    this.onEditingComplete,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      readOnly: readOnly,
      onChanged: onChanged,
      style: style,
      textAlign: textAlign,
      onEditingComplete: onEditingComplete,
      decoration: InputDecoration(
          fillColor: Colors.transparent,
          filled: false,
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          hintText: hint,
          hintStyle: hintStyle,
          border: const OutlineInputBorder(borderSide: BorderSide.none)),
    );
  }
}
