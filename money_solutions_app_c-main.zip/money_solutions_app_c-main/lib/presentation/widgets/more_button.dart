import 'package:flutter/material.dart';

class MoreButton extends StatelessWidget {
  final String label;
  final Color labelColor;
  final double labelSize;
  final Widget suffixIcon;
  final Function()? onTap;

  const MoreButton({
    super.key,
    required this.label,
    this.labelColor = Colors.white,
    required this.suffixIcon,
    required this.onTap,
    this.labelSize = 11,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        child: Row(
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: labelSize,
                color: labelColor,
              ),
            ),
            const SizedBox(width: 4),
            suffixIcon,
          ],
        ),
      ),
    );
  }
}
