import 'dart:math';

import 'package:flutter/material.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/shapes.dart';

class AppButton extends StatelessWidget {
  final Widget prefix;
  final String label;
  final TextStyle? labelStyle;
  final Widget suffix;
  final Function() onTap;
  final EdgeInsets padding;
  final Gradient? gradient;
  final Color backgroundColor;
  final ShapeBorder shape;
  final double elevation;

  const AppButton({
    super.key,
    this.prefix = const SizedBox(),
    required this.label,
    this.labelStyle,
    this.suffix = const SizedBox(),
    required this.onTap,
    this.padding = const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
    this.gradient,
    this.backgroundColor = Colors.transparent,
    this.shape = mediumShape,
    this.elevation = 0,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: shape,
      elevation: elevation,
      child: InkWell(
        onTap: onTap,
        child: Container(
          constraints: BoxConstraints(maxHeight: 56),
          decoration: BoxDecoration(
            gradient: gradient,
            color: gradient == null ? backgroundColor : null,
          ),
          child: Stack(
            children: [
              Positioned.fill(
                child: Image.asset(
                  'assets/images/button_bg.png',
                  fit: BoxFit.cover,
                ),
              ),
              Padding(
                padding: padding,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    prefix,
                    Text(
                      label,
                      style: labelStyle ??
                          const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: AppColors.backgroundColor,
                          ),
                    ),
                    suffix,
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
