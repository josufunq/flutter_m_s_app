import 'package:auto_route/annotations.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/screens/account/widgets/score_card.dart';
import 'package:money_solutions_app_c/presentation/screens/account/widgets/score_field.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/main_title.dart';
import 'package:money_solutions_app_c/presentation/widgets/top_bar.dart';

@RoutePage()
class ScoresScreen extends StatelessWidget {
  const ScoresScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: const TopBar(),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.backgroundColor,
                Color(0xFF2C6F7D),
              ],
            ),
          ),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 40),
                MainTitle(title: 'Цели'),
                SizedBox(height: 40),
                ScoreField(title: 'Установленный бюджет', value: 1370000),
                SizedBox(height: 16),
                ScoreField(title: 'Всего накоплено', value: 350000),
                SizedBox(height: 16),
                ScoreField(title: 'Остаток', value: 1020000),
                SizedBox(height: 36),
                ScoreCard(title: 'Покупка машины', value: 10000),
                SizedBox(height: 16),
                ScoreCard(title: 'Отпуск', value: 2500),
                SizedBox(height: 16),
                ScoreCard(title: 'Отпуск', value: 2500),
                SizedBox(height: 16),
                ScoreCard(title: 'Покупка машины', value: 200000),
                SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
