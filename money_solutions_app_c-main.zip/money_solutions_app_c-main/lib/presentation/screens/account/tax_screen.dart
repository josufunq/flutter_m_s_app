import 'package:auto_route/annotations.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/screens/account/widgets/score_card.dart';
import 'package:money_solutions_app_c/presentation/screens/account/widgets/score_field.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/main_title.dart';
import 'package:money_solutions_app_c/presentation/widgets/top_bar.dart';

@RoutePage()
class TaxScreen extends StatelessWidget {
  const TaxScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: const TopBar(),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.backgroundColor,
                Color(0xFF2C6F7D),
              ],
            ),
          ),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 40),
                MainTitle(title: 'Налоги'),
                SizedBox(height: 40),
                ScoreField(title: 'Установленный бюджет', value: 13000),
                SizedBox(height: 16),
                ScoreField(title: 'Всего накоплено', value: 7350),
                SizedBox(height: 16),
                ScoreField(title: 'Остаток', value: 5650),
                SizedBox(height: 36),
                ScoreCard(title: 'Транспортный налог', value: 7350),
                SizedBox(height: 16),
                ScoreCard(title: 'Имущественный налог', value: 0),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
