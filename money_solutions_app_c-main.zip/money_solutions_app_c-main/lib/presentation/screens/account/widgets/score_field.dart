import 'package:flutter/cupertino.dart';
import 'package:intl/intl.dart';

class ScoreField extends StatelessWidget {
  final String title;
  final double value;
  const ScoreField({
    super.key,
    required this.title,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
        ),
        Text(
          '${NumberFormat('###0').format(value)} руб',
          style: const TextStyle(fontSize: 15, color: Color(0xFF9D9D9C)),
        ),
      ],
    );
  }
}
