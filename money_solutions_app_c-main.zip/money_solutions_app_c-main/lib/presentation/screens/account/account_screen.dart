import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:money_solutions_app_c/app_router.gr.dart';
import 'package:money_solutions_app_c/blocs/account/account_cubit.dart';
import 'package:money_solutions_app_c/data/models/account/account.dart';
import 'package:money_solutions_app_c/data/models/credit_card.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/screens/account/widgets/account_card.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/card_shape.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/main_title.dart';
import 'package:money_solutions_app_c/presentation/shapes.dart';
import 'package:money_solutions_app_c/presentation/widgets/classic_text_field.dart';
import 'package:money_solutions_app_c/presentation/widgets/more_button.dart';
import 'package:uuid/uuid.dart';

@RoutePage()
class AccountScreen extends StatefulWidget {
  AccountScreen({super.key});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  final TextEditingController _nameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) {
        var cubit = AccountCubit();
        cubit.loadAccountData();

        return cubit;
      },
      child: SafeArea(
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: const Size.fromHeight(70),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    IconButton(
                      onPressed: () => context.router.pop(),
                      icon: const Icon(
                        CupertinoIcons.chevron_back,
                      ),
                    ),
                    IconButton(
                      onPressed: () => context.router.pop(),
                      icon: const Icon(
                        Icons.settings,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          body: SingleChildScrollView(
            child: BlocConsumer<AccountCubit, AccountState>(
              listener: (context, state) {
                state.whenOrNull(
                  successLoaded: (account) {
                    if (account != null) {
                      _nameController.text = account.name;
                    }
                  },
                  successSaved: () {
                    //BlocProvider.of<AccountCubit>(context).loadAccountData();
                  },
                );
              },
              buildWhen: (previous, current) {
                return current.when(initial: () => true, loading: () => true, error: (err) => true, successLoaded: (acc) => true, successSaved: () => false);
              },
              builder: (context, state) {
                return state.whenOrNull(
                  initial: () => const SizedBox(),
                  error: (error) => Center(child: Text(error)),
                  loading: () => const Center(child: CircularProgressIndicator()),
                  successLoaded: (account) => Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 30),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 48,
                              height: 48,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                              ),
                              child: Image.asset('assets/images/image_pa.png'),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: ClassicTextField(
                                hint: 'Введите имя',
                                style: const TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w700,
                                ),
                                textAlign: TextAlign.start,
                                controller: _nameController,
                                onEditingComplete: () {
                                  BlocProvider.of<AccountCubit>(context).saveAccountData(
                                    Account(
                                      name: _nameController.text,
                                      cards: account != null
                                          ? account.cards
                                          : [
                                              CreditCard(uid: const Uuid().v8(), balance: 0, expirationDate: DateTime.now().add(const Duration(days: 1000))),
                                            ],
                                    ),
                                  );

                                  FocusScope.of(context).unfocus();
                                },
                                onChanged: (value) {},
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 32),
                        account?.cards != null
                            ? Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const MainTitle(title: 'Зарегистрированные карты'),
                                  const SizedBox(height: 28),
                                  CardShape(
                                    card: account!.cards[0],
                                    onTap: () {},
                                  ),
                                  const SizedBox(height: 42),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      const MainTitle(title: 'Планировщик бюджета'),
                                      MoreButton(
                                        label: 'Подробнее',
                                        labelColor: AppColors.descriptionColor,
                                        suffixIcon: const Card(
                                          shape: circleShape,
                                          color: AppColors.grey900,
                                          child: Padding(
                                            padding: EdgeInsets.all(4.0),
                                            child: Icon(
                                              CupertinoIcons.chevron_forward,
                                              size: 8,
                                            ),
                                          ),
                                        ),
                                        onTap: () {
                                          context.router.push(PlannerRoute());
                                        },
                                      )
                                    ],
                                  ),
                                  const SizedBox(height: 35),
                                  const MainTitle(title: 'Декабрьский'),
                                  const SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: AccountCard(
                                          title: 'Цели',
                                          totalPrice: 0,
                                          onTap: () {
                                            context.router.push(ScoresRoute());
                                          },
                                        ),
                                      ),
                                      const SizedBox(width: 20),
                                      Expanded(
                                        child: AccountCard(
                                          title: 'Налоги',
                                          totalPrice: 0,
                                          onTap: () {
                                            context.router.push(TaxRoute());
                                          },
                                        ),
                                      ),
                                    ],
                                  )
                                ],
                              )
                            : const SizedBox(),
                      ],
                    ),
                  ),
                )!;
              },
            ),
          ),
        ),
      ),
    );
  }
}
