import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:money_solutions_app_c/app_router.gr.dart';
import 'package:money_solutions_app_c/blocs/transaction/transaction_cubit.dart';
import 'package:money_solutions_app_c/data/models/subscription.dart';
import 'package:money_solutions_app_c/presentation/widgets/history_card.dart';
import 'package:money_solutions_app_c/presentation/widgets/top_bar.dart';

@RoutePage()
class SubscriptionsScreen extends StatelessWidget {
  const SubscriptionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) {
        var transactionCubit = TransactionCubit();
        transactionCubit.loadTransfers();

        return transactionCubit;
      },
      child: SafeArea(
        child: Scaffold(
            appBar: const TopBar(),
            body: BlocBuilder<TransactionCubit, TransactionState>(
              builder: (context, state) {
                return state.whenOrNull(
                  initial: () => const SizedBox(),
                  loading: () => const Center(child: CircularProgressIndicator()),
                  loadSuccess: (transactions) {
                    List<Subscription> subscriptions = [];

                    for (var transaction in transactions) {
                      if (transaction.typeName == 'Оплата подписки' &&
                          subscriptions.indexWhere((element) => element.subscriptionName.toLowerCase() == transaction.name.toLowerCase()) == -1) {
                        subscriptions.add(Subscription(subscriptionName: transaction.name, imageAsset: transaction.image));
                      }
                    }

                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 20),
                          const Text(
                            "Активные подписки на данный момент",
                            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                          ),
                          const SizedBox(height: 40),
                          Expanded(
                            child: ListView.builder(
                              itemCount: subscriptions.length,
                              shrinkWrap: true,
                              itemBuilder: (itemBuilder, index) {
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 14),
                                  child: SubscriptionCard(
                                    subscription: subscriptions[index],
                                    onTap: () {
                                      context.router.push(SubscriptionHistoryRoute(subscription: subscriptions[index]));
                                    },
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                  error: (error) => Center(child: Text(error)),
                )!;
              },
            )),
      ),
    );
  }
}
