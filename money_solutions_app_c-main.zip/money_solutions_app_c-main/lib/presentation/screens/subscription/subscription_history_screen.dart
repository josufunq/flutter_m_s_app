import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:money_solutions_app_c/blocs/transaction/transaction_cubit.dart';
import 'package:money_solutions_app_c/data/models/subscription.dart';
import 'package:money_solutions_app_c/data/models/transfer.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/widgets/app_button.dart';
import 'package:money_solutions_app_c/presentation/widgets/history_card.dart';
import 'package:money_solutions_app_c/presentation/widgets/top_bar.dart';

@RoutePage()
class SubscriptionHistoryScreen extends StatelessWidget {
  final Subscription subscription;

  SubscriptionHistoryScreen({super.key, required this.subscription});

  double totalPrice = 0;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) {
        var transactionCubit = TransactionCubit();
        transactionCubit.loadTransfers();

        return transactionCubit;
      },
      child: SafeArea(
        child: Scaffold(
          appBar: const TopBar(),
          body: BlocConsumer<TransactionCubit, TransactionState>(
            listener: (context, state) {
              state.whenOrNull(
                loadSuccess: (transactions) {
                  totalPrice = 0;

                  List<Transfer> sortedTransactions =
                      transactions.where((element) => element.name.toLowerCase() == subscription.subscriptionName.toLowerCase()).toList();

                  for (var element in sortedTransactions) {
                    totalPrice += element.count;
                  }
                },
              );
            },
            builder: (context, state) {
              return state.whenOrNull(
                  initial: () => const SizedBox(),
                  loading: () => const Center(child: CircularProgressIndicator()),
                  loadSuccess: (transactions) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 18),
                          Row(
                            children: [
                              Container(
                                height: 48,
                                width: 48,
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                ),
                                child: Image.asset(
                                  subscription.imageAsset,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              const SizedBox(width: 16),
                              Text(
                                subscription.subscriptionName,
                                style: const TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 32),
                          const Text("История оплаты", style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 10),
                          Expanded(
                            child: ListView.builder(
                              itemCount: transactions.where((element) => element.name.toLowerCase() == subscription.subscriptionName.toLowerCase()).length,
                              shrinkWrap: true,
                              itemBuilder: (itemBuilder, index) {
                                List<Transfer> sortedTransactions =
                                    transactions.where((element) => element.name.toLowerCase() == subscription.subscriptionName.toLowerCase()).toList();

                                Transfer? transfer = sortedTransactions[index];
                                Transfer? previousTransfer = index != 0 ? sortedTransactions[index - 1] : null;

                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 8.0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      transfer.date.day != previousTransfer?.date.day && transfer.date.month != previousTransfer?.date.month
                                          ? Padding(
                                              padding: const EdgeInsets.only(bottom: 8),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.end,
                                                children: [
                                                  Text(
                                                    DateFormat('dd MMMM yyyy').format(transfer.date),
                                                    style: const TextStyle(
                                                      fontSize: 11,
                                                      color: AppColors.descriptionColor,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            )
                                          : const SizedBox(),
                                      HistoryCard(
                                        transfer: transfer,
                                        dateFormat: 'HH:mm',
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                          const SizedBox(height: 40),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                "Всего потрачено",
                                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                              ),
                              Text(
                                "${NumberFormat('#0').format(totalPrice)} руб",
                                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                          const SizedBox(height: 40),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 30),
                            child: AppButton(
                              label: 'Отменить подписку',
                              padding: EdgeInsets.all(18),
                              onTap: () {},
                            ),
                          )
                        ],
                      ),
                    );
                  })!;
            },
          ),
        ),
      ),
    );
  }
}
