import 'package:auto_route/annotations.dart';
import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:money_solutions_app_c/app_router.gr.dart';
import 'package:money_solutions_app_c/blocs/account/account_cubit.dart';
import 'package:money_solutions_app_c/blocs/transaction/transaction_cubit.dart';
import 'package:money_solutions_app_c/data/models/account/account.dart';
import 'package:money_solutions_app_c/data/models/credit_card.dart';
import 'package:money_solutions_app_c/data/models/transfer.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/card_shape.dart';
import 'package:money_solutions_app_c/presentation/widgets/history_card.dart';
import 'package:money_solutions_app_c/presentation/widgets/more_button.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/transfer_card.dart';
import 'package:money_solutions_app_c/presentation/shapes.dart';
import 'package:uuid/uuid.dart';

import 'widgets/main_title.dart';

@RoutePage()
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) {
            var cubit = TransactionCubit();
            cubit.loadTransfers();

            return cubit;
          },
        ),
        BlocProvider(
          create: (context) {
            var cubit = AccountCubit();
            cubit.loadAccountData();

            return cubit;
          },
        )
      ],
      child: BlocBuilder<TransactionCubit, TransactionState>(
        builder: (context, state) {
          return state.whenOrNull(
            initial: () => const SizedBox(),
            loading: () => const Center(child: CircularProgressIndicator()),
            loadSuccess: (transfers) => SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 16),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const MainTitle(title: 'Карты'),
                        MoreButton(
                          label: 'Добавить карту',
                          suffixIcon: const Card(
                            shape: circleShape,
                            color: Color(0xFFB4F2E1),
                            child: Icon(
                              Icons.add,
                              color: Colors.black,
                              size: 16,
                            ),
                          ),
                          onTap: () {},
                        )
                      ],
                    ),
                    const SizedBox(height: 24),
                    BlocConsumer<AccountCubit, AccountState>(
                      listener: (context, state) {
                        state.whenOrNull(
                          successLoaded: (account) {
                            if (account == null) {
                              BlocProvider.of<AccountCubit>(context).saveAccountData(
                                Account(
                                  name: '',
                                  cards: [
                                    CreditCard(uid: const Uuid().v8(), balance: 0, expirationDate: DateTime.now().add(const Duration(days: 1000))),
                                  ],
                                ),
                              );
                            }
                          },
                          successSaved: () {
                            context.router.push(MainRoute());
                            //BlocProvider.of<AccountCubit>(context).loadAccountData();
                          },
                        );
                      },
                      buildWhen: (previous, current) {
                        return current.when(
                            initial: () => false, loading: () => true, error: (err) => true, successLoaded: (acc) => true, successSaved: () => false);
                      },
                      builder: (context, state) {
                        return state.whenOrNull(
                          loading: () => const Center(child: CircularProgressIndicator()),
                          error: (error) => Center(child: Text(error)),
                          successLoaded: (account) => account != null
                              ? CardShape(
                                  card: CreditCard(
                                    balance: account.cards[0].balance,
                                    uid: account.cards[0].uid,
                                    expirationDate: account.cards[0].expirationDate,
                                  ),
                                  onTap: () {},
                                )
                              : const SizedBox(),
                        )!;
                      },
                    ),
                    const SizedBox(height: 30),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const MainTitle(title: 'Последние переводы'),
                        MoreButton(
                          label: 'Подробнее',
                          labelColor: AppColors.descriptionColor,
                          suffixIcon: const Card(
                            shape: circleShape,
                            color: AppColors.grey900,
                            child: Padding(
                              padding: EdgeInsets.all(4.0),
                              child: Icon(
                                CupertinoIcons.chevron_forward,
                                size: 8,
                              ),
                            ),
                          ),
                          onTap: () {},
                        )
                      ],
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: List.generate(
                        3,
                        (index) => Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            child: TransferCard(
                              transfer: Transfer(
                                uid: 'uid',
                                name: 'name',
                                count: 151,
                                date: DateTime.now(),
                                image: 'assets/images/image_person_1.png',
                                type: 0,
                                typeName: 'transfer',
                                description: '',
                              ),
                              onTap: () {},
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const MainTitle(title: 'Подписки'),
                        MoreButton(
                          label: 'Подробнее',
                          labelColor: AppColors.descriptionColor,
                          suffixIcon: const Card(
                            shape: circleShape,
                            color: AppColors.grey900,
                            child: Padding(
                              padding: EdgeInsets.all(4.0),
                              child: Icon(
                                CupertinoIcons.chevron_forward,
                                size: 8,
                              ),
                            ),
                          ),
                          onTap: () {
                            context.router.push(const SubscriptionsRoute());
                          },
                        )
                      ],
                    ),
                    const SizedBox(height: 24),
                    ListView.builder(
                      itemCount: transfers.where((element) => element.typeName == 'Оплата подписки').length,
                      shrinkWrap: true,
                      itemBuilder: (context, index) => Column(
                        children: [
                          HistoryCard(transfer: transfers.where((element) => element.typeName == 'Оплата подписки').toList()[index]),
                          const SizedBox(height: 8),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            error: (error) => Center(child: Text(error)),
          )!;
        },
      ),
    );
  }
}
