import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';
import 'package:money_solutions_app_c/data/models/credit_card.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';

class CardShape extends StatelessWidget {
  final CreditCard card;
  final Function() onTap;
  const CardShape({super.key, required this.card, required this.onTap});

  @override
  Widget build(BuildContext context) {
    DateFormat dateFormat = DateFormat('MM/yy');
    return Card(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Container(
          color: Colors.white,
          child: Stack(
            children: [
              Image.asset(
                'assets/images/card_bg.png',
                fit: BoxFit.cover,
              ),
              Container(
                padding: const EdgeInsets.all(25.0),
                height: 200,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Текущий баланс',
                              style: TextStyle(
                                color: Color(0xFF525354),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              NumberFormat("###0.00", "ru_RU").format(card.balance),
                              style: const TextStyle(
                                fontSize: 29,
                                fontWeight: FontWeight.w700,
                                color: AppColors.backgroundColor,
                              ),
                            ),
                          ],
                        ),
                        SvgPicture.asset(
                          'assets/images/logo_visa.svg',
                          color: AppColors.backgroundColor,
                        )
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Подробнее',
                          style: TextStyle(
                            fontSize: 14,
                            color: Color(0xFF393A3B),
                          ),
                        ),
                        Text(
                          dateFormat.format(card.expirationDate),
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: AppColors.backgroundColor,
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
