import 'package:flutter/material.dart';

class MainTitle extends StatelessWidget {
  final String title;
  final TextAlign? textAlign;
  const MainTitle({super.key, required this.title, this.textAlign});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 17,
        fontWeight: FontWeight.w700,
      ),
      textAlign: textAlign,
    );
  }
}
