import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:money_solutions_app_c/data/models/transfer.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/shapes.dart';

class TransferCard extends StatelessWidget {
  final Transfer transfer;
  final Function() onTap;

  const TransferCard({
    super.key,
    required this.transfer,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: mediumShape,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(28.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(transfer.image),
              const SizedBox(height: 8),
              Text(
                transfer.name,
                style: const TextStyle(
                  color: AppColors.descriptionColor,
                  fontSize: 11,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                '${transfer.count.toString()} руб',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
