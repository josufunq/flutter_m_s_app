import 'package:auto_route/annotations.dart';
import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:money_solutions_app_c/app_router.gr.dart';
import 'package:money_solutions_app_c/blocs/account/account_cubit.dart';
import 'package:money_solutions_app_c/data/models/credit_card.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/screens/account/account_screen.dart';
import 'package:money_solutions_app_c/presentation/screens/main/home_screen.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/card_shape.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/main_title.dart';
import 'package:money_solutions_app_c/presentation/widgets/more_button.dart';
import 'package:money_solutions_app_c/presentation/shapes.dart';

@RoutePage()
class MainScreen extends StatelessWidget {
  const MainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) {
        var cubit = AccountCubit();
        cubit.loadAccountData();

        return cubit;
      },
      child: BlocBuilder<AccountCubit, AccountState>(
        builder: (context, state) {
          return state.whenOrNull(
            initial: () => const SizedBox(),
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error) => Center(child: Text(error)),
            successLoaded: (account) => SafeArea(
              child: Scaffold(
                appBar: PreferredSize(
                  preferredSize: const Size.fromHeight(70),
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: SvgPicture.asset('assets/icons/ic_menu.svg'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                body: const HomeScreen(),
                bottomNavigationBar: BottomNavigationBar(
                  showSelectedLabels: false,
                  showUnselectedLabels: false,
                  backgroundColor: AppColors.backgroundColor,
                  onTap: (screen) {
                    switch (screen) {
                      case 1:
                        {
                          context.router.push(WalletRoute(card: account!.cards[0]));
                        }
                        break;
                      case 2:
                        {
                          context.router.push(AccountRoute());
                        }
                        break;
                      default:
                        {}
                        break;
                    }
                  },
                  items: [
                    BottomNavigationBarItem(
                      label: '',
                      icon: SvgPicture.asset('assets/icons/ic_home.svg'),
                    ),
                    BottomNavigationBarItem(
                      label: '',
                      icon: SvgPicture.asset('assets/icons/ic_wallet.svg'),
                    ),
                    BottomNavigationBarItem(
                      label: '',
                      icon: SvgPicture.asset('assets/icons/ic_user.svg'),
                    ),
                  ],
                ),
              ),
            ),
          )!;
        },
      ),
    );
  }
}
