import 'dart:math';

import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:money_solutions_app_c/app_router.gr.dart';
import 'package:money_solutions_app_c/blocs/plan/plan_cubit.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/screens/account/widgets/score_card.dart';
import 'package:money_solutions_app_c/presentation/screens/account/widgets/score_field.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/main_title.dart';
import 'package:money_solutions_app_c/presentation/screens/planner/widgets/planner_card.dart';
import 'package:money_solutions_app_c/presentation/shapes.dart';
import 'package:money_solutions_app_c/presentation/widgets/more_button.dart';
import 'package:money_solutions_app_c/presentation/widgets/top_bar.dart';

@RoutePage()
class PlannerScreen extends StatelessWidget {
  const PlannerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) {
        var planCubit = PlanCubit();
        planCubit.loadPlans();

        return planCubit;
      },
      child: SafeArea(
        child: Scaffold(
          appBar: const TopBar(),
          body: BlocBuilder<PlanCubit, PlanState>(
            builder: (context, state) {
              return state.when(
                initial: () => const SizedBox(),
                loading: () => const Center(child: CircularProgressIndicator()),
                loadSuccess: (plans) => Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        AppColors.backgroundColor,
                        Color(0xFF2C6F7D),
                      ],
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 40),
                        const MainTitle(title: 'Планирования'),
                        const SizedBox(height: 24),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            MoreButton(
                              label: 'Добавить планирование',
                              suffixIcon: const Card(
                                shape: circleShape,
                                color: Color(0xFFB4F2E1),
                                child: Icon(
                                  Icons.add,
                                  color: Colors.black,
                                  size: 16,
                                ),
                              ),
                              onTap: () {
                                context.router.push(CreatePlanRoute());
                              },
                            ),
                          ],
                        ),
                        const SizedBox(height: 25),
                        ListView.builder(
                          shrinkWrap: true,
                          itemCount: plans.length,
                          itemBuilder: (context, index) {
                            return PlannerCard(
                              plan: plans[index],
                              onTap: () {
                                context.router.push(SavePlanRoute(plan: plans[index], isInfo: true));
                              },
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
                addSuccess: () => const SizedBox(),
                error: (error) => Center(child: Text(error)),
              );
            },
          ),
        ),
      ),
    );
  }
}
