import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:money_solutions_app_c/app_router.gr.dart';
import 'package:money_solutions_app_c/data/models/planner/plan.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/main_title.dart';
import 'package:money_solutions_app_c/presentation/screens/planner/create_outcome_plan_screen.dart';
import 'package:money_solutions_app_c/presentation/shapes.dart';
import 'package:money_solutions_app_c/presentation/widgets/app_button.dart';
import 'package:money_solutions_app_c/presentation/widgets/classic_text_field.dart';
import 'package:money_solutions_app_c/presentation/widgets/more_button.dart';
import 'package:money_solutions_app_c/presentation/widgets/top_bar.dart';

@RoutePage()
class CreatePlanScreen extends StatefulWidget {
  CreatePlanScreen({super.key});

  @override
  State<CreatePlanScreen> createState() => _CreatePlanScreenState();
}

class _CreatePlanScreenState extends State<CreatePlanScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _incomeController = TextEditingController();
  final TextEditingController _unexpectedIncomeController = TextEditingController();

  DateTimeRange? _dateTimeRange;

  @override
  Widget build(BuildContext context) {
    DateFormat dateFormat = DateFormat('dd.MM.yyyy');
    return SafeArea(
      child: Scaffold(
        appBar: const TopBar(),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.backgroundColor,
                Color(0xFF2C6F7D),
              ],
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 40),
                const MainTitle(title: 'Создание планирования'),
                const SizedBox(height: 24),
                Expanded(
                  child: CustomScrollView(
                    slivers: [
                      SliverFillRemaining(
                        hasScrollBody: false,
                        child: Column(
                          children: [
                            const MainTitle(
                              title: 'Введите первоначальные данные вашего бюджета на определенный период',
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 70),
                            const Text('Название', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                            ClassicTextField(hint: '', controller: _nameController),
                            const SizedBox(height: 20),
                            InkWell(
                              onTap: () async {
                                _dateTimeRange = await showDateRangePicker(context: context, firstDate: DateTime(1900), lastDate: DateTime(9999));
                                setState(() {});
                              },
                              child: Text(
                                _dateTimeRange == null
                                    ? 'Период'
                                    : "Период\n${dateFormat.format(_dateTimeRange!.start)} - ${dateFormat.format(_dateTimeRange!.start)}",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            const SizedBox(height: 60),
                            const Text('Сумма точного дохода', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                            ClassicTextField(hint: '', controller: _incomeController),
                            const SizedBox(height: 20),
                            const Text('Сумма непредвиденного дохода', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                            ClassicTextField(hint: '', controller: _unexpectedIncomeController),
                            const SizedBox(height: 50),
                            AppButton(
                              label: 'Продолжить',
                              onTap: () {
                                context.router.push(
                                  CreateOutcomePlanRoute(
                                    plan: Plan(
                                      title: _nameController.text,
                                      dateStart: _dateTimeRange!.start,
                                      dateEnd: _dateTimeRange!.end,
                                      income: double.parse(_incomeController.text),
                                      unexpectedIncome: double.parse(_unexpectedIncomeController.text),
                                      outcomes: [],
                                      additionalOutcome: 0,
                                    ),
                                  ),
                                );
                              },
                            ),
                            const SizedBox(height: 50),
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
