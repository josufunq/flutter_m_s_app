import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:money_solutions_app_c/data/models/planner/plan.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/shapes.dart';

class PlannerCard extends StatelessWidget {
  final Plan plan;
  final Function() onTap;

  const PlannerCard({
    super.key,
    required this.plan,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    DateFormat dateFormat = DateFormat('dd.MM.yyyy');
    return Card(
      margin: EdgeInsets.only(bottom: 4),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    plan.title,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const Card(
                    shape: circleShape,
                    color: Color(0xFF2C6F7D),
                    child: Padding(
                      padding: EdgeInsets.all(6.0),
                      child: Icon(
                        CupertinoIcons.chevron_forward,
                        size: 8,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              RichText(
                text: TextSpan(
                  children: [
                    const TextSpan(
                      text: 'Период плана: ',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                    ),
                    TextSpan(
                      text: '${dateFormat.format(plan.dateStart)} - ${dateFormat.format(plan.dateEnd)}',
                      style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                        color: AppColors.descriptionColor,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              RichText(
                text: TextSpan(
                  children: [
                    const TextSpan(
                      text: 'Общий доход: ',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                    ),
                    TextSpan(
                      text: '${plan.income}',
                      style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                        color: AppColors.descriptionColor,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              RichText(
                text: TextSpan(
                  children: [
                    const TextSpan(
                      text: 'Общий расход: ',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                    ),
                    TextSpan(
                      text: '${plan.outcomes.fold(0.0, (previousValue, element) => previousValue + element)}',
                      style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                        color: AppColors.descriptionColor,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
