import 'package:flutter/cupertino.dart';
import 'package:intl/intl.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';

class PlannerField extends StatelessWidget {
  final String title;
  final TextStyle titleStyle;
  final String content;
  final TextStyle contentStyle;

  const PlannerField({
    super.key,
    required this.title,
    required this.content,
    this.titleStyle = const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
    this.contentStyle = const TextStyle(fontSize: 16),
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: '$title: ',
              style: titleStyle,
            ),
            TextSpan(
              text: content,
              style: contentStyle,
            ),
          ],
        ),
      ),
    );
  }
}
