import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:money_solutions_app_c/app_router.gr.dart';
import 'package:money_solutions_app_c/data/models/planner/plan.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/main_title.dart';
import 'package:money_solutions_app_c/presentation/widgets/app_button.dart';
import 'package:money_solutions_app_c/presentation/widgets/classic_text_field.dart';
import 'package:money_solutions_app_c/presentation/widgets/top_bar.dart';

@RoutePage()
class CreateResultPlanScreen extends StatefulWidget {
  final Plan plan;
  const CreateResultPlanScreen({super.key, required this.plan});

  @override
  State<CreateResultPlanScreen> createState() => _CreateResultPlanScreenState();
}

class _CreateResultPlanScreenState extends State<CreateResultPlanScreen> {
  late final double _sumOutcome = widget.plan.outcomes.fold<double>(0.0, (previousValue, element) => previousValue + element);
  late final double _remains = widget.plan.income - _sumOutcome;

  final TextEditingController _additionalOutcomeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: const TopBar(),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.backgroundColor,
                Color(0xFF2C6F7D),
              ],
            ),
          ),
          child: CustomScrollView(
            slivers: [
              SliverFillRemaining(
                hasScrollBody: false,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const SizedBox(height: 40),
                      const Row(
                        children: [
                          MainTitle(title: 'Создание планирования'),
                        ],
                      ),
                      const SizedBox(height: 24),
                      const MainTitle(
                        title: 'Общий расход финансов на данные период составил:',
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 30),
                      Text(
                        '${NumberFormat('#0').format(_sumOutcome)} руб',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 30),
                      const MainTitle(
                        title: 'Остаточный допустимый расход с учетом вашей прибыли составил:',
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 30),
                      Text(
                        '${NumberFormat('#0').format(_remains)} руб',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 30),
                      const Text('Введите дополнительный расход', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                      ClassicTextField(hint: '', controller: _additionalOutcomeController),
                      const SizedBox(height: 40),
                      AppButton(
                        label: 'Продолжить',
                        onTap: () {
                          context.router.push(
                            SavePlanRoute(
                              plan: widget.plan.copyWith(
                                additionalOutcome: _additionalOutcomeController.text.isNotEmpty ? double.parse(_additionalOutcomeController.text) : 0,
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
