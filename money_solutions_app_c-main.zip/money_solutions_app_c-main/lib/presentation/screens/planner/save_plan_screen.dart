import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:money_solutions_app_c/app_router.gr.dart';
import 'package:money_solutions_app_c/blocs/plan/plan_cubit.dart';
import 'package:money_solutions_app_c/data/models/planner/plan.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/main_title.dart';
import 'package:money_solutions_app_c/presentation/screens/planner/planner_screen.dart';
import 'package:money_solutions_app_c/presentation/screens/planner/widgets/planner_field.dart';
import 'package:money_solutions_app_c/presentation/widgets/top_bar.dart';

@RoutePage()
class SavePlanScreen extends StatelessWidget {
  final Plan plan;
  final bool isInfo;

  SavePlanScreen({super.key, required this.plan, this.isInfo = false});

  final DateFormat dateFormat = DateFormat('dd.MM.yyyy');

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => PlanCubit(),
      child: SafeArea(
        child: BlocConsumer<PlanCubit, PlanState>(listener: (context, state) {
          state.whenOrNull(addSuccess: () => context.router.push(const PlannerRoute()));
        }, builder: (context, state) {
          return Scaffold(
            appBar: TopBar(
              suffix: !isInfo
                  ? InkWell(
                      onTap: () {
                        BlocProvider.of<PlanCubit>(context).addPlan(plan);
                      },
                      child: const Text(
                        'Сохранить',
                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                      ),
                    )
                  : null,
            ),
            body: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    AppColors.backgroundColor,
                    Color(0xFF2C6F7D),
                  ],
                ),
              ),
              child: CustomScrollView(
                slivers: [
                  SliverFillRemaining(
                    hasScrollBody: false,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 20),
                          const MainTitle(title: 'Данные о планировании'),
                          const SizedBox(height: 20),
                          PlannerField(title: 'Название', content: plan.title),
                          PlannerField(title: 'Период', content: '${dateFormat.format(plan.dateStart)} - ${dateFormat.format(plan.dateEnd)}'),
                          PlannerField(title: 'Сумма точного дохода', content: NumberFormat('#0.00', 'ru_RU').format(plan.income)),
                          PlannerField(title: 'Сумма непредвиденного дохода', content: NumberFormat('#0.00', 'ru_RU').format(plan.unexpectedIncome)),
                          PlannerField(
                            title: 'Сумма точного расхода',
                            content: NumberFormat('#0.00', 'ru_RU').format(plan.outcomes.fold(0.0, (previousValue, element) => previousValue + element)),
                          ),
                          PlannerField(title: 'Сумма непредвиденного расхода', content: NumberFormat('#0.00', 'ru_RU').format(plan.additionalOutcome)),
                          const SizedBox(height: 40),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Text(
                              'Распределение финансов по категориям',
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          const SizedBox(height: 40),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Постоянные затраты: ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                              const SizedBox(height: 5),
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      height: 1,
                                      decoration: const BoxDecoration(
                                          gradient: LinearGradient(
                                        colors: [
                                          Color(0x00FFFFFF),
                                          Color(0xFFFFFFFF),
                                          Color(0x00FFFFFF),
                                        ],
                                      )),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 5),
                              PlannerField(
                                title: 'Предполагаемая сумма',
                                titleStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                                content:
                                    '${NumberFormat('#0', 'ru_RU').format(plan.outcomes.fold(0.0, (previousValue, element) => previousValue + element))} руб',
                              ),
                              PlannerField(
                                title: 'Уже потрачено',
                                titleStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                                content:
                                    '${NumberFormat('#0', 'ru_RU').format(plan.outcomes.fold(0.0, (previousValue, element) => previousValue + element))} руб',
                              ),
                              const SizedBox(height: 25),
                              const Text('Налоги: ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                              const SizedBox(height: 5),
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      height: 1,
                                      decoration: const BoxDecoration(
                                          gradient: LinearGradient(
                                        colors: [
                                          Color(0x00FFFFFF),
                                          Color(0xFFFFFFFF),
                                          Color(0x00FFFFFF),
                                        ],
                                      )),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 5),
                              PlannerField(
                                title: 'Имущественный',
                                titleStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                                content: plan.outcomes[1] != 0 ? '${NumberFormat('#0', 'ru_RU').format(plan.outcomes[1])} руб' : 'отсутствует',
                              ),
                              PlannerField(
                                title: 'Транспортный',
                                titleStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                                content: plan.outcomes[2] != 0 ? '${NumberFormat('#0', 'ru_RU').format(plan.outcomes[2])} руб' : 'отсутствует',
                              ),
                              const SizedBox(height: 25),
                              const Text('Здоровье: ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                              const SizedBox(height: 5),
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      height: 1,
                                      decoration: const BoxDecoration(
                                          gradient: LinearGradient(
                                        colors: [
                                          Color(0x00FFFFFF),
                                          Color(0xFFFFFFFF),
                                          Color(0x00FFFFFF),
                                        ],
                                      )),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 5),
                              PlannerField(
                                title: 'Общая сумма',
                                titleStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                                content: plan.outcomes[3] != 0 ? '${NumberFormat('#0', 'ru_RU').format(plan.outcomes[3])} руб' : 'отсутствует',
                              ),
                              const SizedBox(height: 25),
                              const Text('Цели: ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                              const SizedBox(height: 5),
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      height: 1,
                                      decoration: const BoxDecoration(
                                          gradient: LinearGradient(
                                        colors: [
                                          Color(0x00FFFFFF),
                                          Color(0xFFFFFFFF),
                                          Color(0x00FFFFFF),
                                        ],
                                      )),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 5),
                              const PlannerField(
                                title: 'Покупка машины',
                                titleStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                                content: '1300000,00 руб',
                              ),
                              const Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  PlannerField(
                                    title: 'Накоплено',
                                    titleStyle: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                                    content: '300000,00 руб',
                                    contentStyle: TextStyle(fontSize: 12),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 25),
                              const PlannerField(
                                title: 'Отпуск',
                                titleStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                                content: '70000,00 руб',
                              ),
                              const Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  PlannerField(
                                    title: 'Накоплено',
                                    titleStyle: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                                    content: '50000,00 руб',
                                    contentStyle: TextStyle(fontSize: 12),
                                  ),
                                ],
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }
}
