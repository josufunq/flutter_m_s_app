import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:money_solutions_app_c/app_router.gr.dart';
import 'package:money_solutions_app_c/data/models/planner/plan.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/main_title.dart';
import 'package:money_solutions_app_c/presentation/shapes.dart';
import 'package:money_solutions_app_c/presentation/widgets/app_button.dart';
import 'package:money_solutions_app_c/presentation/widgets/classic_text_field.dart';
import 'package:money_solutions_app_c/presentation/widgets/more_button.dart';
import 'package:money_solutions_app_c/presentation/widgets/top_bar.dart';

@RoutePage()
class CreateOutcomePlanScreen extends StatelessWidget {
  final Plan plan;
  CreateOutcomePlanScreen({super.key, required this.plan});

  final TextEditingController _staticOutcomesController = TextEditingController();
  final TextEditingController _propertyTaxController = TextEditingController();
  final TextEditingController _vehicleTaxController = TextEditingController();
  final TextEditingController _healthController = TextEditingController();
  final TextEditingController _scoreOutcome = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: const TopBar(),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.backgroundColor,
                Color(0xFF2C6F7D),
              ],
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 40),
                const MainTitle(title: 'Создание планирования'),
                const SizedBox(height: 24),
                Expanded(
                  child: CustomScrollView(
                    slivers: [
                      SliverFillRemaining(
                        hasScrollBody: false,
                        child: Column(
                          children: [
                            const MainTitle(
                              title: 'Введите траты финансов по категориям',
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 60),
                            const Text('Постоянные затраты', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                            ClassicTextField(hint: '', controller: _staticOutcomesController),
                            const SizedBox(height: 10),
                            const Text('Имущественный налог', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                            ClassicTextField(hint: '', controller: _propertyTaxController),
                            const SizedBox(height: 10),
                            const Text('Транспортный налог', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                            ClassicTextField(hint: '', controller: _vehicleTaxController),
                            const SizedBox(height: 10),
                            const Text('Здоровье', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                            ClassicTextField(hint: '', controller: _healthController),
                            const SizedBox(height: 10),
                            const Text('Оклад на цели', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                            ClassicTextField(hint: '', controller: _scoreOutcome),
                            const SizedBox(height: 30),
                            AppButton(
                              label: 'Продолжить',
                              onTap: () {
                                context.router.push(
                                  CreateResultPlanRoute(
                                    plan: plan.copyWith(
                                      outcomes: [
                                        _staticOutcomesController.text.isNotEmpty ? double.parse(_staticOutcomesController.text) : 0,
                                        _propertyTaxController.text.isNotEmpty ? double.parse(_propertyTaxController.text) : 0,
                                        _vehicleTaxController.text.isNotEmpty ? double.parse(_vehicleTaxController.text) : 0,
                                        _healthController.text.isNotEmpty ? double.parse(_healthController.text) : 0,
                                        _scoreOutcome.text.isNotEmpty ? double.parse(_scoreOutcome.text) : 0,
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
