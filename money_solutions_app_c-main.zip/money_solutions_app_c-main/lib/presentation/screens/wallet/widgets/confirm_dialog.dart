import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:money_solutions_app_c/data/models/transfer.dart';
import 'package:money_solutions_app_c/presentation/widgets/history_card.dart';
import 'package:money_solutions_app_c/presentation/widgets/app_button.dart';

class ConfirmDialog extends StatelessWidget {
  final Transfer transfer;
  final Function(Transfer) onSave;

  const ConfirmDialog({
    super.key,
    required this.transfer,
    required this.onSave,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(70),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                IconButton(
                  onPressed: () => context.router.pop(),
                  icon: const Icon(
                    CupertinoIcons.chevron_back,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(),
            Text(
              transfer.type == 1 ? 'Подтвердите поступление' : 'Подтвердите списание',
              style: const TextStyle(
                fontSize: 29,
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.center,
            ),
            HistoryCard(transfer: transfer, dateFormat: 'HH:mm'),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30),
              child: Column(
                children: [
                  AppButton(
                    label: 'Отредактировать',
                    onTap: () {
                      context.router.pop();
                    },
                  ),
                  const SizedBox(height: 50),
                  AppButton(
                    label: 'Сохранить',
                    onTap: () {
                      onSave(transfer);
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(),
          ],
        ),
      ),
    );
  }
}
