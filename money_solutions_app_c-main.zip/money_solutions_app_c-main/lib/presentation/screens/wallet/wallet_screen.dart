import 'package:auto_route/annotations.dart';
import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:money_solutions_app_c/app_router.gr.dart';
import 'package:money_solutions_app_c/blocs/account/account_cubit.dart';
import 'package:money_solutions_app_c/blocs/transaction/transaction_cubit.dart';
import 'package:money_solutions_app_c/data/models/credit_card.dart';
import 'package:money_solutions_app_c/data/models/transfer.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/widgets/history_card.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/main_title.dart';
import 'package:money_solutions_app_c/presentation/widgets/more_button.dart';
import 'package:money_solutions_app_c/presentation/screens/wallet/history_screen.dart';
import 'package:money_solutions_app_c/presentation/shapes.dart';
import 'package:money_solutions_app_c/presentation/widgets/app_button.dart';

@RoutePage()
class WalletScreen extends StatelessWidget {
  final CreditCard card;
  const WalletScreen({super.key, required this.card});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) {
            var cubit = TransactionCubit();
            cubit.loadTransfers();
            return cubit;
          },
        ),
        BlocProvider(
          create: (context) {
            var cubit = AccountCubit();
            cubit.loadAccountData();

            return cubit;
          },
        ),
      ],
      child: SafeArea(
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: const Size.fromHeight(70),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    IconButton(
                      onPressed: () {
                        context.router.pop();
                      },
                      icon: const Icon(
                        CupertinoIcons.chevron_back,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  const Row(
                    children: [
                      SizedBox(height: 30),
                    ],
                  ),
                  const Text(
                    'Баланс',
                    style: TextStyle(
                      fontSize: 15,
                      color: AppColors.descriptionColor,
                    ),
                  ),
                  const SizedBox(height: 11),
                  Text(
                    NumberFormat("###0.00", "ru_RU").format(card.balance),
                    style: const TextStyle(
                      fontSize: 29,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 70),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40),
                    child: Column(
                      children: [
                        AppButton(
                          label: 'Добавить поступление',
                          onTap: () {
                            context.router.push(ManageTransactionRoute(transferType: 1));
                          },
                        ),
                        const SizedBox(height: 57),
                        AppButton(
                          label: 'Добавить списание',
                          onTap: () {
                            context.router.push(ManageTransactionRoute(transferType: 0));
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 117),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const MainTitle(title: 'Операции'),
                      MoreButton(
                        label: 'История',
                        labelColor: AppColors.descriptionColor,
                        suffixIcon: const Card(
                          shape: circleShape,
                          color: AppColors.grey900,
                          child: Padding(
                            padding: EdgeInsets.all(4.0),
                            child: Icon(
                              CupertinoIcons.chevron_forward,
                              size: 8,
                            ),
                          ),
                        ),
                        onTap: () {
                          context.router.push(const HistoryRoute());
                        },
                      )
                    ],
                  ),
                  const SizedBox(height: 28),
                  BlocBuilder<TransactionCubit, TransactionState>(
                    builder: (context, state) {
                      return state.whenOrNull(
                          initial: () => const SizedBox(),
                          loading: () => const Center(child: CircularProgressIndicator()),
                          loadSuccess: (transactions) {
                            return Column(
                              children: List.generate(
                                transactions.length > 2 ? 2 : transactions.length,
                                (index) => Padding(
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: HistoryCard(transfer: transactions[index]),
                                ),
                              ),
                            );
                          },
                          error: (error) => Center(child: Text(error)))!;
                    },
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
