import 'dart:ui';

import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:money_solutions_app_c/app_router.gr.dart';
import 'package:money_solutions_app_c/blocs/account/account_cubit.dart';
import 'package:money_solutions_app_c/blocs/transaction/transaction_cubit.dart';
import 'package:money_solutions_app_c/data/models/transfer.dart';
import 'package:money_solutions_app_c/presentation/screens/wallet/widgets/confirm_dialog.dart';
import 'package:money_solutions_app_c/presentation/widgets/app_button.dart';
import 'package:money_solutions_app_c/presentation/widgets/classic_text_field.dart';
import 'package:uuid/uuid.dart';

@RoutePage()
class ManageTransactionScreen extends StatefulWidget {
  final int transferType; // 0 - outcome, 1 - income

  ManageTransactionScreen({super.key, required this.transferType});

  @override
  State<ManageTransactionScreen> createState() => _ManageTransactionScreenState();
}

class _ManageTransactionScreenState extends State<ManageTransactionScreen> {
  final TextEditingController _summController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();

  final List<String> _incomeTypes = ['Зарплата', 'Прочий доход', 'Пополнение средств'];
  final List<String> _outcomesTypes = ['Продукты', 'Лекарства', 'Одежда', 'Оплата налога', 'Переводы', 'Развлечения', 'Учеба', 'Оплата подписки'];

  int _selectedTransferType = 0;

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => TransactionCubit(),
        ),
        BlocProvider(
          create: (context) => AccountCubit(),
        ),
      ],
      child: SafeArea(
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: const Size.fromHeight(70),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    IconButton(
                      onPressed: () => context.router.pop(),
                      icon: const Icon(
                        CupertinoIcons.chevron_back,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          body: BlocConsumer<TransactionCubit, TransactionState>(
            listener: (context, state) {
              state.whenOrNull(
                addSuccess: () => context.router.push(const MainRoute()),
                error: (error) {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      content: Text(error),
                      actions: [
                        AppButton(
                          label: 'Ок',
                          onTap: () {
                            context.router.pop();
                          },
                        ),
                      ],
                    ),
                  );
                },
              );
            },
            builder: (context, state) => SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    Text(
                      widget.transferType == 1 ? "Поступления" : "Списания",
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 40),
                    Card(
                      color: Colors.transparent,
                      child: Container(
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Color(0xFF1B1B1D),
                              Color(0x001B1B1D),
                            ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 18),
                          child: Column(
                            children: [
                              const SizedBox(height: 20),
                              Text(
                                widget.transferType == 1 ? "Выберите тип поступления" : "Выберите тип списания",
                                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                              ),
                              const SizedBox(height: 30),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  IconButton(
                                    onPressed: () {
                                      if (_selectedTransferType > 0) {
                                        _selectedTransferType--;
                                        setState(() {});
                                      }
                                    },
                                    icon: const Icon(
                                      CupertinoIcons.chevron_back,
                                    ),
                                  ),
                                  const Spacer(),
                                  Text(
                                    widget.transferType == 1 ? _incomeTypes[_selectedTransferType] : _outcomesTypes[_selectedTransferType],
                                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                                  ),
                                  const Spacer(),
                                  IconButton(
                                    onPressed: () {
                                      if (widget.transferType == 1) {
                                        if (_selectedTransferType < _incomeTypes.length - 1) {
                                          _selectedTransferType++;
                                          setState(() {});
                                        }
                                      } else {
                                        if (_selectedTransferType < _outcomesTypes.length - 1) {
                                          _selectedTransferType++;
                                          setState(() {});
                                        }
                                      }
                                    },
                                    icon: const Icon(
                                      CupertinoIcons.chevron_forward,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 30),
                              Text(
                                widget.transferType == 1 ? "Введите сумму поступления" : "Введите сумму списания",
                                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                              ),
                              const SizedBox(height: 20),
                              ClassicTextField(hint: "Сумма", controller: _summController),
                              const SizedBox(height: 40),
                              Text(
                                widget.transferType == 1 ? "Введите данные отправителя" : "Введите данные получателя",
                                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                              ),
                              const SizedBox(height: 20),
                              ClassicTextField(
                                hint: widget.transferType == 1 ? "Данные отправителя" : "Данные получателя",
                                controller: _nameController,
                              ),
                              const SizedBox(height: 40),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    AppButton(
                      label: widget.transferType == 1 ? "Добавить поступление" : "Добавить списание",
                      onTap: () {
                        context.router.pushWidget(
                          ConfirmDialog(
                            transfer: Transfer(
                              uid: const Uuid().v8(),
                              name: _nameController.text,
                              count: double.parse(_summController.text),
                              date: DateTime.now(),
                              image: 'assets/images/image_person_3.png',
                              type: widget.transferType,
                              typeName: widget.transferType == 0 ? _outcomesTypes[_selectedTransferType] : _incomeTypes[_selectedTransferType],
                              description: widget.transferType == 0 ? _outcomesTypes[_selectedTransferType] : _incomeTypes[_selectedTransferType],
                            ),
                            onSave: (transfer) {
                              BlocProvider.of<TransactionCubit>(context).addTransfer(transfer);
                              if (widget.transferType == 1) {
                                BlocProvider.of<AccountCubit>(context).changeBalance(double.parse(_summController.text), 0);
                              } else {
                                BlocProvider.of<AccountCubit>(context).changeBalance(-double.parse(_summController.text), 0);
                              }
                            },
                          ),
                          fullscreenDialog: true,
                        );
                      },
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
