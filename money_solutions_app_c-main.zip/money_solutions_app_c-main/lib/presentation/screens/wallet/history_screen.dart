import 'package:auto_route/annotations.dart';
import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:money_solutions_app_c/blocs/transaction/transaction_cubit.dart';
import 'package:money_solutions_app_c/data/models/transfer.dart';
import 'package:money_solutions_app_c/presentation/colors.dart';
import 'package:money_solutions_app_c/presentation/widgets/history_card.dart';
import 'package:money_solutions_app_c/presentation/screens/main/widgets/main_title.dart';

@RoutePage()
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) {
        var cubit = TransactionCubit();
        cubit.loadTransfers();
        return cubit;
      },
      child: SafeArea(
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: const Size.fromHeight(70),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    IconButton(
                      onPressed: () => context.router.pop(),
                      icon: const Icon(
                        CupertinoIcons.chevron_back,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          body: BlocBuilder<TransactionCubit, TransactionState>(
            builder: (context, state) {
              return state.when(
                initial: () => const SizedBox(),
                loading: () => const Center(child: CircularProgressIndicator()),
                loadSuccess: (transfers) => ListView.builder(
                  itemCount: transfers.length,
                  itemBuilder: (context, index) {
                    Transfer? transfer = transfers[index];
                    Transfer? previousTransfer = index != 0 ? transfers[index - 1] : null;
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Column(
                        children: [
                          transfer.date.day != previousTransfer?.date.day && transfer.date.month != previousTransfer?.date.month
                              ? Padding(
                                  padding: const EdgeInsets.only(bottom: 24),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      index == 0 ? const MainTitle(title: 'Операции') : const SizedBox(),
                                      Text(
                                        DateFormat('dd MMMM yyyy').format(transfers[index].date),
                                        style: const TextStyle(
                                          fontSize: 11,
                                          color: AppColors.descriptionColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : const SizedBox(),
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: HistoryCard(
                              transfer: transfers[index],
                              dateFormat: 'HH:mm',
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                addSuccess: () => const SizedBox(),
                error: (error) => Center(child: Text(error)),
              );
            },
          ),
        ),
      ),
    );
  }
}
