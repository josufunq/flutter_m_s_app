import 'dart:ui';

import 'package:flutter/material.dart';

const double smallBorderRadiusValue = 8;
const double mediumBorderRadiusValue = 16;
const double largeBorderRadiusValue = 24;

const Radius smallBorderRadius = Radius.circular(smallBorderRadiusValue);
const Radius mediumBorderRadius = Radius.circular(mediumBorderRadiusValue);
const Radius largeBorderRadius = Radius.circular(largeBorderRadiusValue);

const RoundedRectangleBorder smallShape = RoundedRectangleBorder(borderRadius: BorderRadius.all(smallBorderRadius));
const RoundedRectangleBorder mediumShape = RoundedRectangleBorder(borderRadius: BorderRadius.all(mediumBorderRadius));
const RoundedRectangleBorder largeShape = RoundedRectangleBorder(borderRadius: BorderRadius.all(largeBorderRadius));

const RoundedRectangleBorder circleShape = RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(999)));
