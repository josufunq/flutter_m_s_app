import 'package:auto_route/auto_route.dart';
import 'package:money_solutions_app_c/app_router.gr.dart';
import 'package:money_solutions_app_c/presentation/screens/account/tax_screen.dart';

@AutoRouterConfig()
class AppRouter extends $AppRouter {
  @override
  List<AutoRoute> get routes => [
        AutoRoute(
          path: '/',
          page: MainRoute.page,
          initial: true,
        ),
        AutoRoute(
          path: '/wallet',
          page: WalletRoute.page,
        ),
        AutoRoute(
          path: '/manage_transaction',
          page: ManageTransactionRoute.page,
        ),
        AutoRoute(
          path: '/wallet_history',
          page: HistoryRoute.page,
        ),
        AutoRoute(
          path: '/subscriptions',
          page: SubscriptionsRoute.page,
        ),
        AutoRoute(
          path: '/account',
          page: AccountRoute.page,
        ),
        AutoRoute(
          path: '/subscriptions',
          page: SubscriptionHistoryRoute.page,
        ),
        AutoRoute(
          path: '/scores',
          page: ScoresRoute.page,
        ),
        AutoRoute(
          path: '/taxes',
          page: TaxRoute.page,
        ),
        AutoRoute(
          path: '/planner',
          page: PlannerRoute.page,
        ),
        AutoRoute(
          path: '/create_plan_1',
          page: CreatePlanRoute.page,
        ),
        AutoRoute(
          path: '/create_plan_2',
          page: CreateOutcomePlanRoute.page,
        ),
        AutoRoute(
          path: '/create_plan_3',
          page: CreateResultPlanRoute.page,
        ),
        AutoRoute(
          path: '/save_plan',
          page: SavePlanRoute.page,
        ),
      ];
}
